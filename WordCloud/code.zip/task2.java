package word;

import java.util.ArrayList;
import java.util.List;

public class task2 {
	/*
	 * 输入:task1获得的String[]
	 */
public static List<Word> count(List<String> a) {
	List<Word> wds=new ArrayList<Word>();
	for(String s:a) {
		boolean has=false;
		for(int i=0;i<wds.size();i++) 			
			if(s.equalsIgnoreCase(wds.get(i).getWord())) {
				has=true;
				wds.get(i).setFre(wds.get(i).getFre()+1);
				break;
			}		
		if(has==false)
			wds.add(new Word(s,1));		
	}
	for(int i=0;i<wds.size();i++) {
		for(int j=i;j<wds.size();j++) {
			if(wds.get(i).getFre()<wds.get(j).getFre()) {
				Word t=wds.get(i);
				wds.set(i, wds.get(j));
				wds.set(j, t);
			}
		}
	}
	return wds;
}
}
