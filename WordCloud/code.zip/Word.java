package word;

public class Word
{
String word;
int fre;
public Word(String word,int fre) {
	this.word=word;
	this.fre=fre;
}
public String getWord()
{
	return word;
}
public void setWord(String word)
{
	this.word = word;
}
public int getFre()
{
	return fre;
}
public void setFre(int fre)
{
	this.fre = fre;
}

}