package word;
import java.io.BufferedReader;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import com.hankcs.hanlp.seg.Segment;
import com.hankcs.hanlp.seg.NShort.NShortSegment;
import com.hankcs.hanlp.seg.common.Term;
public class task1 {
	/*
	 * 要读取的文件路径
	 */
	public static List<String> sep (String string) {
		try {			
			File badwords = new File("data/dictionary/stopwords.txt");
			BufferedReader bwb=new BufferedReader(new InputStreamReader(new FileInputStream(badwords)));
			List<String> bws = new ArrayList<String>();
			String bline=bwb.readLine();
			while(bline!=null) {
				bws.add(bline);
				bline=bwb.readLine();
			}
			bwb.close();
			String pathname = string;
			File file = new File(pathname);// 在对应的文件路径读取文件且生成java能理解的文件file类的对象
			InputStreamReader reader = new InputStreamReader(new FileInputStream(file));// 输入流，reader是文件的输入流对象
			BufferedReader br = new BufferedReader(reader);// 从reader中获取文件内容并放进br对象中			
			String line = br.readLine();
			List<String> re = new ArrayList<String>();
			while(line!=null) {
				//选择N最短路分词器，效果好一点
				Segment nShortSegment = new NShortSegment().enableCustomDictionary(false).enablePlaceRecognize(true).enableOrganizationRecognize(true);
				List<Term> termList =nShortSegment.seg(line);
				for(Term t : termList) {//遍历这一行的分词
					String s=t.word;
					boolean cover=false;
					for(String bw:bws)  //对分词遍历badword
						if(s.equalsIgnoreCase(bw)) {
							cover=true;
							break;		
						}
					if(cover==false)re.add(s);
				}
				line = br.readLine();
			}
			br.close();
			return re;//.toArray(new String[re.size()]);			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
