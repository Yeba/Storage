package word;

import javax.swing.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Windows {	
	static File file=null;
	static Color chosecol=task3.bgm[0];//选择的颜色
	static boolean haspic=true;//是否生成图片
	static int limit=2;//限制词频
	public static void setlimit(int i) {
		limit=i;
	}
	/*
	 * 生成task3实例，运行
	 */
	static void run() {
		task3 t3=new task3();
		t3.setFile(file);
		t3.setLimit(limit);
		t3.setpic(haspic);
		t3.setBgm(chosecol);
		try {
			t3.generate();
		} catch (AWTException e) {
			e.printStackTrace();
		}		
	}
	/*
	 * 构造窗体
	 */
    public static void main(String[] args) {
        final JFrame jf = new JFrame("Word Cloud");
        jf.setSize(800, 700);
        String span="          ";
        setlimit(2);
        JTextField brgb=new JTextField();//输入rgb
        brgb.getDocument().addDocumentListener(new DocumentListener(){
        	void getrgb(String s) {
        		String[] ss=s.split(" ");
        		if(ss.length!=3)return;
        		chosecol=new Color(Integer.parseInt(ss[0]),Integer.parseInt(ss[1]),Integer.parseInt(ss[2])); 
        	}
			@Override
			public void changedUpdate(DocumentEvent e) { getrgb(brgb.getText()); }
			@Override
			public void insertUpdate(DocumentEvent e) { getrgb(brgb.getText()); }
			@Override
			public void removeUpdate(DocumentEvent e) { getrgb(brgb.getText()); }	
        });
        
        final JComboBox<String> blist = new JComboBox<String>(new String[]{"自选","预设1","预设2","预设3","预设4","预设5","预设6","预设7"});
        blist.setSelectedIndex(1);
        blist.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
            	int i=blist.getSelectedIndex();
            	if(i==0) {
            		Color color = JColorChooser.showDialog(jf, "选取颜色", chosecol);
            		if(color!=null) chosecol=color;
            	} else 
            		chosecol=task3.bgm[i-1];
                showRGB(brgb,chosecol);
            }
        });        
        
        Box bmid=Box.createVerticalBox();
        bmid.add(blist);  
        bmid.add(new JLabel("或者输入R,G,B （空格以隔开）:     "));      
        bmid.add(brgb);
        Box bbox=Box.createHorizontalBox();//背景总体水平布局                
        bbox.add( new JLabel("背景色："));bbox.add(new JLabel(span));
        bbox.add(bmid);
        bbox.add(new JLabel(span));
        
        
        JButton tfile=new JButton("选择文件");        
        Box tbox=Box.createHorizontalBox();//文本总体水平布局
        tbox.add(new JLabel("文本："));tbox.add(new JLabel(span));
        tbox.add(tfile);
        tbox.add(Box.createHorizontalGlue());
        tfile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	file= showFileOpenDialog(jf);
            	tfile.setText(file.getName());
            }
        });
                         
        
        JRadioButton iyes = new JRadioButton("是");
        JRadioButton ino= new JRadioButton("不");
        iyes.setSelected(true);
        ino.setSelected(false);
        iyes.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent arg0) {
				haspic=iyes.isSelected();
			}        	
        });
        ButtonGroup btnGroup = new ButtonGroup();
        btnGroup.add(ino);
        btnGroup.add(iyes);        
        
        Box ibox=Box.createHorizontalBox();//选项总体水平布局
        ibox.add(new JLabel("是否生成同名图片？"));ibox.add(new JLabel(span));        
        ibox.add(iyes);ibox.add(new JLabel(span));        
        ibox.add(ino);ibox.add(new JLabel(span));
        
        
        JButton go=new JButton("开始");
        go.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	if(file!=null) {
            		run();
            	}            		
            }
        });
        Box bgo=Box.createHorizontalBox();
        bgo.add(Box.createHorizontalGlue());
        bgo.add(go);
        bgo.add(Box.createHorizontalGlue());
        
        Box box=Box.createVerticalBox();//总窗口
        box.add(bbox);box.add(new JLabel(span));box.add(new JLabel(span));
        box.add(tbox);box.add(new JLabel(span));box.add(new JLabel(span));
        box.add(ibox);box.add(new JLabel(span));box.add(new JLabel(span));box.add(new JLabel(span));
        box.add(bgo);
        
        jf.setContentPane(box);
        jf.pack();
        jf.setVisible(true);
    }
    /*
     * 在l这个JTextField中展示Color c 的RGB
     */
    static void showRGB(JTextField l,Color c) {
    	l.setText(String.valueOf(c.getRed())+" "+String.valueOf(c.getGreen())+" "+String.valueOf(c.getBlue()));
    }
    /*
     * 选择文件
     */
    static File showFileOpenDialog(Component parent) {
    	File re=null;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File("."));
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setMultiSelectionEnabled(false);
        fileChooser.setFileFilter(new FileNameExtensionFilter("text(*.txt)", "txt","TXT"));
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            re = fileChooser.getSelectedFile();
        }
        return re;
    }

}
