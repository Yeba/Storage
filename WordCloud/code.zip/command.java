package word;

public class command {
	public String s;
	public boolean dire;//false:横   true:竖
	public int x;//左上角  少舍   (int)d
	public int y;//
	public int w;//宽高  多入，留空   (int)d +1
	public int h;
	public int size; //（频率-1）*20
	//color
}
