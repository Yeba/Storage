package word;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
public class task3 {
	boolean haspic=true;//是否生成同名jpg图片
	static int limit=2;//限定频率大于等于2 的词会出现，可调
	static boolean[][] pt=null;
	static List<command> cs=new ArrayList<command>();
	static int hei=600;//wid=hei*2  初始化大小，会自动跳转
	static int margin=12;//词和词之间的边距，可调
	static Color[] bgm= {new Color(255, 255, 255),new Color(255, 204, 255),new Color(204, 236, 255),new Color(204, 255, 255),new Color(204, 255, 204),new Color(255, 255, 204),new Color(255, 204, 204)};
	static Color[] color= {new Color(0, 255, 255),new Color(0, 51, 153),new Color(102, 153, 255),new Color(102, 0, 204),new Color(255, 0, 255),//这些颜色来自ppt
			new Color(204, 51, 153),new Color(255, 80, 80),new Color(153, 51, 0),new Color(255, 255, 0),new Color(102, 102, 51),new Color(51, 204, 51),new Color(51, 153, 102)};
	static File file=null;
	Color bco=bgm[0];
	public void setFile(File s) {
		file=s;
	}
	public void setLimit(int i) {
		limit=i;
	}
	public void setpic(boolean b) {
		haspic=b;
	}
	public void setBgm(Color c) {
		bco=c;
	}
	/*
	 * 生成词云
	 */
	public void generate() throws AWTException {
		List<Word> wds=task2.count(task1.sep(file.getAbsolutePath()));
		for(int i=0;i<wds.size();i++)//去除出现次数过少的词语
			if(wds.get(i).getFre()<limit) {
				wds.remove(i);
				i--;
			}
		TextBoard tb = new TextBoard(hei*2,hei,bco);
		int size=0;
		Rectangle2D rec =null;
		for(int i=0;i<wds.size();i++) {//测量每个词语的占地，以计算生成图片大小
			command c=new command();
			c.s=wds.get(i).getWord();
			c.size=20*(wds.get(i).getFre()-1);
			Font font=new Font("Msyh",Font.PLAIN,c.size);
			rec = tb.getBounds(c.s, font, 200, 200);
			c.w=(int)rec.getWidth()+1;
			c.h=(int)rec.getHeight()+1;
			size+=(c.w+margin)*(c.h+margin);
			cs.add(c);
		}
		hei =(int)(Math.sqrt(size));//得到图片大小
		tb.setSize(hei*2, hei);		
		pt=new boolean[hei*2][hei]; 
		for(int x=0;x<hei*2;x++) {//初始化，使形成椭圆的云状
			double h=1.0*hei/2*Math.sqrt(1.0-Math.pow(1.0*x/hei-1,2));
			for(int y=(int) (hei/2-h);y<(int) (hei/2+h)*0.9;y++) {
				pt[x][y]=true;
			}
		}
		boolean dir=false;//方向
		int col=1;
		for(int i=0;i<cs.size();i++) {//放置
			boolean puted=false;
			dir=!dir; 
			col++;if(col==color.length)col=1;
			if(dir) if(cs.get(i).w>hei*0.6) dir=!dir;
			cs.get(i).dire=dir;
			if(!puted)
			for(int xx=0;xx<hei*2;xx++) {
				if(!puted)
				for(int yy=0;yy<hei;yy++) {
					if(!puted)
					if(okToPut(i,xx,yy)) {	
						puted=true;
						Font font = new Font("SansSerif", Font.PLAIN, cs.get(i).size);
						if(dir) tb.write(cs.get(i).s, -(yy+cs.get(i).w+cs.get(i).size/5),xx+cs.get(i).h, -90, font,color[col]);
						else tb.write(cs.get(i).s, xx,yy+cs.get(i).h, 0, font, color[col]);
						break;
					}
				}
			}
			if(!puted)System.out.println(cs.get(i).s);
		}
		tb.display();//展示
		savePic(tb);
	}
	/*
	 * 检测x，y这一点是否可以防止cs[i]
	 */
	static boolean okToPut(int i,int x,int y) {
		if(cs.get(i).h+y>hei ||cs.get(i).w+x>hei*2)return false;
		int x1,x2,y1,y2;
		if(cs.get(i).dire) {//竖
			x1=x;x2=x+cs.get(i).h;
			y1=y;y2=y+cs.get(i).w;
		}else {
			x1=x;x2=x+cs.get(i).w;
			y1=y;y2=y+cs.get(i).h;
		}
		if(x2+margin<pt.length)x2+=margin;
		if(y2+margin<pt[0].length)y2+=margin;	
		for(int i1=x1;i1<x2;i1++) 
			for(int j=y1;j<y2;j++) 
				if(!pt[i1][j])return false;	
		if(x2+margin<pt.length)x2+=margin;
		if(y2+margin<pt[0].length)y2+=margin;	
		for(int i1=x1;i1<x2;i1++) 
			for(int j=y1;j<y2;j++) 
				pt[i1][j]=false;
		return true;
	}	
	/*
	 * 保存为图片
	 */
	public static void savePic(JFrame jf){  
	    Container content=jf.getContentPane();  
	    BufferedImage img=new BufferedImage(jf.getWidth(),jf.getHeight(),BufferedImage.TYPE_INT_RGB); 
	    img=cropImage(img,0,0,hei*2-18,hei-47);//原图右边和下边有黑边，不知道为什么，，这里剪切掉
	    Graphics2D g2d = img.createGraphics();  
	    content.printAll(g2d);  
	    File f=new File(file.getAbsolutePath()+".jpg");  
	    try {  
	        ImageIO.write(img, "jpg", f);  
	    } catch (IOException e) {  
	        e.printStackTrace();  
	    }  
	    g2d.dispose();  
	} 
	/*
	 * 剪切图片，从（startX,startY）到（endX,endY）
	 */
	public static BufferedImage cropImage(BufferedImage bufferedImage, int startX, int startY, int endX, int endY) {
        int width = bufferedImage.getWidth();
        int height = bufferedImage.getHeight();
        if (startX == -1)startX = 0;        
        if (startY == -1)startY = 0;
        if (endX == -1) endX = width - 1;
        if (endY == -1)  endY = height - 1;
        BufferedImage result = new BufferedImage(endX - startX, endY - startY, 4);
        for (int x = startX; x < endX; ++x) 
            for (int y = startY; y < endY; ++y) {
                int rgb = bufferedImage.getRGB(x, y);
                result.setRGB(x - startX, y - startY, rgb);
            }        
        return result;
    }
}